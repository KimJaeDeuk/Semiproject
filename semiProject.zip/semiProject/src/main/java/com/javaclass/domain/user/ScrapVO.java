package com.javaclass.domain.user;

public class ScrapVO {
 private int scrapNo;
 private int customerNo;
 private int pNo;
 private int pPrice;
 private String storedFileName;
 private String pName;
 
 public int getScrapNo() {
	return scrapNo;
}
public void setScrapNo(int scrapNo) {
	this.scrapNo = scrapNo;
}
public int getCustomerNo() {
	return customerNo;
}
public void setCustomerNo(int customerNo) {
	this.customerNo = customerNo;
}
public int getpNo() {
	return pNo;
}
public void setpNo(int pNo) {
	this.pNo = pNo;
}
public String getStoredFileName() {
	return storedFileName;
}
public void setStoredFileName(String storedFileName) {
	this.storedFileName = storedFileName;
}
public String getpName() {
	return pName;
}
public void setpName(String pName) {
	this.pName = pName;
}
public int getpPrice() {
	return pPrice;
}
public void setpPrice(int pPrice) {
	this.pPrice = pPrice;
}

}
